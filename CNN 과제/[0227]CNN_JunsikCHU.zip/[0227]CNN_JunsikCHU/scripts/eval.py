import os
import sys
import yaml
import argparse
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import seaborn as sns

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(ROOT_DIR, "models"))
sys.path.append(os.path.join(ROOT_DIR, "scripts"))

from CustomDataset import CustomImageDataset
from resnet import ResNet50

weights_dir = os.path.join(ROOT_DIR, "weights")
results_dir = os.path.join(ROOT_DIR, "results")
data_dir = os.path.join(ROOT_DIR, "data")
config_path = os.path.join(ROOT_DIR, "configs", "config.yaml")
metadata_path = os.path.join(ROOT_DIR, "data", "metadata.csv")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
num_workers = min(4, os.cpu_count() // 2)

def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate ResNet50 on Pneumonia Dataset")
    parser.add_argument("--augment", action="store_true", help="Applied data augmentation during training")
    return parser.parse_args()

def main():
    args = parse_args()
    augment = args.augment

    # ✅ YAML 파일에서 하이퍼파라미터 로드
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if augment:
        batch_size = config["augmentation"]["hyperparameters"]["batch_size"]
        model_weights = "best_model_augmentation.pth"
    else:
        batch_size = config["no_augmentation"]["hyperparameters"]["batch_size"]
        model_weights = "best_model_no_augmentation.pth"

    # ✅ MetaData.csv 로드 및 Test 데이터 분할
    meta_data = pd.read_csv(metadata_path)
    meta_data["class_id"] = meta_data["class_label"].map({"NORMAL": 0, "PNEUMONIA": 1})

    _, val_test = train_test_split(meta_data, train_size=0.6, stratify=meta_data["class_id"], random_state=2025)
    _, test = train_test_split(val_test, train_size=0.5, stratify=val_test["class_id"], random_state=2025)

    # ✅ Custom Dataset 및 DataLoader 생성
    test_dataset = CustomImageDataset(data_dir=data_dir, df=test, augment=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    # ✅ 모델 선언 및 GPU 할당
    trained_model = ResNet50()
    trained_model.load_state_dict(torch.load(os.path.join(weights_dir, model_weights), map_location=device))
    trained_model.eval()
    trained_model.to(device)

    all_labels = []
    all_predictions = []

    # ✅ 모델 평가
    with torch.no_grad():
        for img, label in test_loader:
            img, label = img.to(device), label.to(device).float()

            # Forward Propagation
            pred = trained_model(img)

            # 예측값 계산
            predicted = (torch.sigmoid(pred) > 0.5).float()

            # 리스트에 저장
            all_labels.append(label)
            all_predictions.append(predicted)

    all_labels = torch.cat(all_labels).cpu().numpy().tolist()
    all_predictions = torch.cat(all_predictions).cpu().numpy().tolist()

    # ✅ Accuracy 계산 및 Confusion Matrix 계산
    accuracy = accuracy_score(all_labels, all_predictions)
    cm = confusion_matrix(all_labels, all_predictions)

    print("Accuracy: {:.2f}%".format(accuracy * 100))

    # ✅ Confusion Matrix 시각화 및 저장
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    
    if augment:
        ax.set_title(f"Confusion Matrix & Accuracy: {accuracy * 100:.2f}% - Augmentation")
        plt.savefig(os.path.join(results_dir, "test_accuracy_augmentation.png"))
    else:
        ax.set_title(f"Confusion Matrix & Accuracy: {accuracy * 100:.2f}% - No Augmentation")
        plt.savefig(os.path.join(results_dir, "test_accuracy_no_augmentation.png"))

    plt.show()

if __name__ == "__main__":
    main()
