import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, out_channels, stride, expansion) -> None:
        #### TO DO ####
        super(ResBottleNeck, self).__init__()
        self.expansion = expansion
        self.relu = nn.ReLU()

        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size= 1, stride= stride, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size= 3, stride= 1, padding= 1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.conv3 = nn.Conv2d(out_channels, out_channels * self.expansion , kernel_size= 1, stride= 1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels * self.expansion)

        self.residual = nn.Sequential()
        if stride != 1 or in_channels != out_channels * self.expansion:
            self.residual = nn.Sequential(
                nn.Conv2d(in_channels, out_channels * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels * self.expansion)
            )

        ###############
        pass
                
    def forward(self, x):
        #### TO DO ####

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.conv3(out)
        out = self.bn3(out)
        out = out + self.residual(x)
        out = self.relu(out)
        x = out
        
        ###############
        return x
    

class ResNet50(nn.Module):
    def __init__(self) -> None:
        #### TO DO ####
        super(ResNet50, self).__init__()

        self.conv1 = nn.Conv2d(3, 64, kernel_size= 7, stride= 2, padding= 3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU()
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer2_1 = ResBottleNeck(64,64,1,4)
        self.layer2_2 = ResBottleNeck(256,64,1,4)
        self.layer2_3 = ResBottleNeck(256,64,1,4)

        self.layer3_1 = ResBottleNeck(256,128,2,4)
        self.layer3_2 = ResBottleNeck(512,128,1,4)
        self.layer3_3 = ResBottleNeck(512,128,1,4)
        self.layer3_4 = ResBottleNeck(512,128,1,4)

        self.layer4_1 = ResBottleNeck(512,256,2,4)
        self.layer4_2 = ResBottleNeck(1024,256,1,4)
        self.layer4_3 = ResBottleNeck(1024,256,1,4)
        self.layer4_4 = ResBottleNeck(1024,256,1,4)
        self.layer4_5 = ResBottleNeck(1024,256,1,4)
        self.layer4_6 = ResBottleNeck(1024,256,1,4)

        self.layer5_1 = ResBottleNeck(1024,512,2,4)
        self.layer5_2 = ResBottleNeck(2048,512,1,4)
        self.layer5_3 = ResBottleNeck(2048,512,1,4)


        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.fc = nn.Linear(2048,1)
        ###############
        pass

    def forward(self, x):
        #### TO DO ####
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer2_1(x)
        x = self.layer2_2(x)
        x = self.layer2_3(x)

        x = self.layer3_1(x)
        x = self.layer3_2(x)
        x = self.layer3_3(x)
        x = self.layer3_4(x)

        x = self.layer4_1(x)
        x = self.layer4_2(x)
        x = self.layer4_3(x)
        x = self.layer4_4(x)
        x = self.layer4_5(x)
        x = self.layer4_6(x)

        x = self.layer5_1(x)
        x = self.layer5_2(x)
        x = self.layer5_3(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        ###############
        return x