import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

"""
metaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):
    def __init__(self, data_dir: str, df: pd.DataFrame, augment=False):
        self.data_dir = data_dir  # 이미지가 저장된 기본 경로
        self.df = df.reset_index(drop=True)  # 인덱스 리셋
        self.augment = augment  # 데이터 증강 여부

        # 데이터 증강 (train 데이터에만 적용)
        if self.augment:
            self.transform = transforms.Compose([
                #### TO DO ####
                # torchvision.transforms를 이용해 다양한 data augmentation 함수들을 사용해주세요


                transforms.RandomAffine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1)), # 회전, 이동, 확대/축소, 기울이기
                transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 1.5)),

                ############### 
                transforms.ToTensor()
            ])
        else:
            self.transform = transforms.ToTensor()  # 정규화 없이 ToTensor()만 적용

    def __len__(self) -> int:
        # self.df에 포함된 전체 데이터포인트의 수를 반환하도록 해주세요
        return len(self.df)

    def __getitem__(self, idx: int):
        # self.df의 각 행에서 받은 image_id, class_label, class_id을 이용해 이미지 데이터와 레이블을 반환해주세요
        
        image = Image.open(os.path.join(self.data_dir,self.df.loc[idx,"class_label"],self.df.loc[idx,"image_id"] + ".jpeg")).convert("RGB")
        label = self.df.loc[idx,"class_id"]

        # 변환 적용 (필수: ToTensor() 포함)
        image = self.transform(image)

        return image, label
