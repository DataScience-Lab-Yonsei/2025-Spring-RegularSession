import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

"""
metaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):
    def __init__(self, data_dir: str, data_list: pd.DataFrame, augment=False):
        self.data_dir = data_dir  # 이미지가 저장된 기본 경로
        self.data_list = data_list.reset_index(drop=True)  # 인덱스 리셋
        self.augment = augment  # 데이터 증강 여부
        
        
            
        # 데이터 증강 (train 데이터에만 적용)
        if self.augment:
            self.transform = transforms.Compose([
                #### TO DO ####
                transforms.ToTensor(),
                # torchvision.transforms를 이용해 다양한 data augmentation 함수들을 사용해주세요
                transforms.RandomResizedCrop(size=224, scale=(0.9, 1.1)),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    #transforms.GaussianBlur(kernel_size=(5, 5), sigma=(0.1, 0.5)),
    transforms.RandomErasing(p=0.25, scale=(0.02, 0.1), ratio=(0.3, 3.3)),
    transforms.RandomAffine(degrees=0, translate=(0.05, 0.05)),
    transforms.RandomGrayscale(p=0.05),
    #transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])

                
                ###############
                
            ])
        else:
            self.transform = transforms.ToTensor()  # 정규화 없이 ToTensor()만 적용

    def __len__(self) -> int:
        # self.data_list에 포함된 전체 데이터포인트의 수를 반환하도록 해주세요
        return len(self.data_list)

    def __getitem__(self, idx: int):
        # self.data_list의 각 행에서 받은 image_id, class_label, class_id을 이용해 이미지 데이터와 레이블을 반환해주세요
        
        row = self.data_list.iloc[idx]
        class_label = row["class_label"]
        image_path = os.path.join(self.data_dir, class_label, f"{row["image_id"]}.jpeg")
        
        image = Image.open(image_path).convert("RGB")

        label = row["class_id"]

        # 변환 적용 (필수: ToTensor() 포함)
        image_t = self.transform(image)

        return image_t, label
