import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, mid_channels, out_channels, stride = 1) -> None:
        super(ResBottleNeck, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, mid_channels, kernel_size=1, stride=stride, bias=False)
        self.bn1 = nn.BatchNorm2d(mid_channels)

        self.conv2 = nn.Conv2d(mid_channels, mid_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(mid_channels)

        self.conv3 = nn.Conv2d(mid_channels, out_channels, kernel_size=1, stride=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        self.relu = nn.ReLU(inplace=True)

        self.downsample = None
        if stride != 1 or in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity
        out = self.relu(out)

        return out

class ResNet50(nn.Module):
    def __init__(self) -> None:
        super(ResNet50, self).__init__()

        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        
        self.layer1 = nn.Sequential(
            ResBottleNeck(64, 64, 256, stride=1),
            ResBottleNeck(256, 64, 256, stride=1),
            ResBottleNeck(256, 64, 256, stride=1),
        )

        self.layer2 = nn.Sequential(
            ResBottleNeck(256, 128, 512, stride=2),
            ResBottleNeck(512, 128, 512, stride=1),
            ResBottleNeck(512, 128, 512, stride=1),
            ResBottleNeck(512, 128, 512, stride=1),
        )

        self.layer3 = nn.Sequential(
            ResBottleNeck(512, 256, 1024, stride=2),
            ResBottleNeck(1024, 256, 1024, stride=1),
            ResBottleNeck(1024, 256, 1024, stride=1),
            ResBottleNeck(1024, 256, 1024, stride=1),
            ResBottleNeck(1024, 256, 1024, stride=1),
            ResBottleNeck(1024, 256, 1024, stride=1),
        )

        self.layer4 = nn.Sequential(
            ResBottleNeck(1024, 512, 2048, stride=2),
            ResBottleNeck(2048, 512, 2048, stride=1),
            ResBottleNeck(2048, 512, 2048, stride=1),
        )
        
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(2048, 1) 

        


    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)

        return x
