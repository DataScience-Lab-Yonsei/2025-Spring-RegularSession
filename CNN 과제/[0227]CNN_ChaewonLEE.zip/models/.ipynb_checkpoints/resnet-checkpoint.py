import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self) -> None:
        #### TO DO ####
                

        
        ###############
        pass
                
    def forward(self, x):
        #### TO DO ####
                

        
        ###############
        return x
    

class ResNet50(nn.Module):
    def __init__(self) -> None:
        #### TO DO ####
                

        
        ###############
        pass

    def forward(self x):
        #### TO DO ####
                

        
        ###############
        return x