import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self) -> None:
        #### TO DO ####
        super().__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels = 3, out_channels = 64, kernel_size = 7, stride = 2, padding = 3),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size = 3, stride = 2, padding = 1)
            )
        self.conv2_1 = nn.Sequential(
            nn.Conv2d(in_channels = 64, out_channels = 64, kernel_size = 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(in_channels = 64, out_channels = 64, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(in_channels = 64, out_channels = 256, kernel_size = 1),
            nn.BatchNorm2d(256)
        )
        self.conv2_2 = nn.Sequential(
            nn.Conv2d(in_channels = 256, out_channels = 64, kernel_size = 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(in_channels = 64, out_channels = 64, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(in_channels = 64, out_channels = 256, kernel_size = 1),
            nn.BatchNorm2d(256)
        )
        self.conv3_1 = nn.Sequential(
            nn.Conv2d(in_channels = 256, out_channels = 128, kernel_size = 1, stride = 2),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(in_channels = 128, out_channels = 128, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(in_channels = 128, out_channels = 512, kernel_size = 1),
            nn.BatchNorm2d(512)
        )
        self.conv3_2 = nn.Sequential(
            nn.Conv2d(in_channels = 512, out_channels = 128, kernel_size = 1, stride = 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(in_channels = 128, out_channels = 128, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(in_channels = 128, out_channels = 512, kernel_size = 1),
            nn.BatchNorm2d(512)
        )        
        self.conv4_1 = nn.Sequential(
            nn.Conv2d(in_channels = 512, out_channels = 256, kernel_size = 1, stride = 2),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(in_channels = 256, out_channels = 256, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(in_channels = 256, out_channels = 1024, kernel_size = 1),
            nn.BatchNorm2d(1024)
        )
        self.conv4_2 = nn.Sequential(
            nn.Conv2d(in_channels = 1024, out_channels = 256, kernel_size = 1, stride = 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(in_channels = 256, out_channels = 256, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(in_channels = 256, out_channels = 1024, kernel_size = 1),
            nn.BatchNorm2d(1024)
        )        
        self.conv5_1  = nn.Sequential(
            nn.Conv2d(in_channels = 1024, out_channels = 512, kernel_size = 1, stride = 2),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(in_channels = 512, out_channels = 512, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(in_channels = 512, out_channels = 2048, kernel_size = 1),
            nn.BatchNorm2d(2048)
        )
        self.conv5_2  = nn.Sequential(
            nn.Conv2d(in_channels = 2048, out_channels = 512, kernel_size = 1, stride = 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(in_channels = 512, out_channels = 512, kernel_size = 3, padding = 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(in_channels = 512, out_channels = 2048, kernel_size = 1),
            nn.BatchNorm2d(2048)
        )

        self.avgpool = nn.AvgPool2d(kernel_size=7)
        self.flatten = nn.Flatten()
        self.fc = nn.Sequential(
            nn.Linear(2048, 1000),
            nn.ReLU(),
            nn.Linear(1000, 1)
        )
        ###############
                
    def forward(self, x):
        #### TO DO ####
        x  = self.conv1(x)
        for i in range(3):
            x = self.relu(x + self.conv2(x))
        for j in range(4):
            if j != 0: self.flag = False
            x = self.relu(x + self.conv3(x))
        self.flag = True
        for k in range(6):
            if k != 0: self.flag = False
            x = self.relu(x + self.conv4(x))
        self.flag = True
        for l in range(3):
            if l != 0: self.flag = False
            x = self.relu(x + self.conv4(x))
        x = self.clf(x)        
        ###############
        return x
    

class ResNet50(ResBottleNeck):
    def __init__(self) -> None:
        #### TO DO ####
        super().__init__()
        print(self.conv1)

        self.clf = nn.Sequential(
            nn.AvgPool2d(kernel_size = 7),
            nn.Linear(in_features = 2048, out_features = 1000),
            nn.ReLU(),
            nn.Linear(1000,1)
        )
        self.relu = nn.ReLU()
        self.proj_convs = nn.ModuleDict({
            'conv2': nn.Conv2d(in_channels = 64, out_channels = 256, kernel_size = 1),
            'conv3': nn.Conv2d(in_channels = 256, out_channels = 512, kernel_size = 1, stride = 2),
            'conv4': nn.Conv2d(in_channels = 512, out_channels = 1024, kernel_size = 1, stride = 2),
            'conv5': nn.Conv2d(in_channels = 1024, out_channels = 2048, kernel_size = 1, stride = 2)
        })
        ###############
        pass

    def forward(self, x):
        #### TO DO ####
        x = self.conv1(x)
        x = self.conv2_1(x)+ self.proj_convs['conv2'](x)
        for i in range(2):
            x = self.conv2_2(x) + x
        x = self.conv3_1(x) + self.proj_convs['conv3'](x)
        for j in range(3):
            x = self.conv3_2(x) + x
        x = self.conv4_1(x) + self.proj_convs['conv4'](x)
        for k in range(5):
            x = self.conv4_2(x) + x
        x = self.conv5_1(x) + self.proj_convs['conv5'](x)
        for l in range(2):
            x = self.conv5_2(x) + x            

        x = self.avgpool(x)
        x = self.flatten(x)
        x = self.fc(x)           
        ###############
        return x