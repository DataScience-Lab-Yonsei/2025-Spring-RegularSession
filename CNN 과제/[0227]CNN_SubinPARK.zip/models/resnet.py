import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, mid_channels, out_channels, stride) -> None:
        #### TO DO ####
        super(ResBottleNeck, self).__init__()
        self.block1 = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, (1, 1), bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(),
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(mid_channels, mid_channels, (3, 3), padding=(1, 1), stride=stride, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(),
        )
        self.block3 = nn.Sequential(
            nn.Conv2d(mid_channels, out_channels, (1, 1), bias=False),
            nn.BatchNorm2d(out_channels),
        )
        self.relu = nn.ReLU()
        if in_channels != out_channels or stride != 1:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, (1, 1), stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )
        else:
            self.shortcut = nn.Identity()
        ###############
        pass
                
    def forward(self, x):
        #### TO DO ####
        out = self.block1(x)
        out = self.block2(out)
        out = self.block3(out)
        x = out + self.shortcut(x)
        x = self.relu(x)
        ###############
        return x
    

class ResNet50(nn.Module):
    def __init__(self) -> None:
        #### TO DO ####
        super(ResNet50, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 64, (7, 7), stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(),
        )
        self.max_pool = nn.MaxPool2d((3, 3), 2)
        self.conv2 = nn.Sequential(
            ResBottleNeck(64, 64, 256, 1),
            *[ResBottleNeck(256, 64, 256, 1) for _ in range(3 - 1)],
        )
        self.conv3 = nn.Sequential(
            ResBottleNeck(256, 128, 512, 2),
            *[ResBottleNeck(512, 128, 512, 1) for _ in range(4 - 1)],
        )
        self.conv4 = nn.Sequential(
            ResBottleNeck(512, 256, 1024, 2),
            *[ResBottleNeck(1024, 256, 1024, 1) for _ in range(6 - 1)],
        )
        self.conv5 = nn.Sequential(
            ResBottleNeck(1024, 512, 2048, 2),
            *[ResBottleNeck(2048, 512, 2048, 1) for _ in range(3 - 1)],
        )
        self.avg_pool = nn.AdaptiveAvgPool2d(output_size=(1, 1))
        self.flatten = nn.Flatten()
        self.linear = nn.Linear(2048, 1)
        ###############
        pass

    def forward(self, x):
        #### TO DO ####
        out = self.conv1(x)
        out = self.max_pool(out)
        out = self.conv2(out)
        out = self.conv3(out)
        out = self.conv4(out)
        out = self.conv5(out)
        out = self.avg_pool(out)
        out = self.flatten(out)
        x = self.linear(out)
        ###############
        return x
    
if __name__ == '__main__':
    x = torch.randn(2, 3, 224, 224)
    model = ResNet50()
    print(model(x).shape)
