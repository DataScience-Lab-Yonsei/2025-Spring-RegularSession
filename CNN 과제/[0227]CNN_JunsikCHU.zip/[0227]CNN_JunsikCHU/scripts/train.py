import os
import sys
import yaml
import argparse
import pandas as pd
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
from torchvision import transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(ROOT_DIR, "models"))
sys.path.append(os.path.join(ROOT_DIR, "scripts"))

from CustomDataset import CustomImageDataset
from resnet import ResNet50

data_dir = os.path.join(ROOT_DIR, "data")
weights_dir = os.path.join(ROOT_DIR, "weights")
results_dir = os.path.join(ROOT_DIR, "results")
config_path = os.path.join(ROOT_DIR, "configs", "config.yaml")
metadata_path = os.path.join(ROOT_DIR, "data", "metadata.csv")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
num_workers = min(4, os.cpu_count() // 2)

def parse_args():
    parser = argparse.ArgumentParser(description="Train ResNet50 on Pneumonia Dataset")
    parser.add_argument("--augment", action="store_true", help="Apply data augmentation during training")
    return parser.parse_args()

def main():
    args = parse_args()
    augment = args.augment

    os.makedirs(weights_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    # ✅ 하이퍼파라미터 설정
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if augment:
        batch_size, lr, epochs = (
            config["augmentation"]["hyperparameters"]["batch_size"],
            float(config["augmentation"]["hyperparameters"]["learning_rate"]),
            config["augmentation"]["hyperparameters"]["num_epochs"]
        )
        model_weights = "best_model_augmentation.pth"
    else:
        batch_size, lr, epochs = (
            config["no_augmentation"]["hyperparameters"]["batch_size"],
            float(config["no_augmentation"]["hyperparameters"]["learning_rate"]),
            config["no_augmentation"]["hyperparameters"]["num_epochs"]
        )
        model_weights = "best_model_no_augmentation.pth"

    # ✅ MetaData.csv 로드 및 Train / Val / Test Split
    meta_data = pd.read_csv(metadata_path)
    meta_data["class_id"] = meta_data["class_label"].map({"NORMAL": 0, "PNEUMONIA": 1})

    train, val_test = train_test_split(meta_data, train_size=0.6, stratify=meta_data["class_id"], random_state=2025)
    val, test = train_test_split(val_test, train_size=0.5, stratify=val_test["class_id"], random_state=2025)

    # ✅ Custom Dataset 및 DataLoader 생성
    train_dataset = CustomImageDataset(data_dir=data_dir, df=train, augment=augment)
    val_dataset = CustomImageDataset(data_dir=data_dir, df=val, augment=False)
    test_dataset = CustomImageDataset(data_dir=data_dir, df=test, augment=False)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    # ✅ 모델 선언 및 GPU 할당
    model = ResNet50()
    model.to(device)

    # ✅ 손실 함수 및 Optimizer 설정
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # ✅ 학습 관련 변수 초기화
    best_loss = float("inf")
    train_loss_list, valid_loss_list = [], []
    train_accuracy_list, valid_accuracy_list = [], []

    # ✅ 학습 진행
    for curr_epoch in range(epochs):
        running_loss, total_correct, total_samples = 0, 0, 0
        model.train()

        for batch_idx, (img, label) in enumerate(train_loader):
            img, label = img.to(device), label.to(device).float()

            optimizer.zero_grad()
            pred = model(img)
            loss = criterion(pred, label.view(-1, 1))
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            predicted = (torch.sigmoid(pred) > 0.5).float()
            total_correct += (predicted == label.view(-1, 1)).sum().item()
            total_samples += label.size(0)

        train_loss = running_loss / len(train_loader)
        train_accuracy = total_correct / total_samples

        # ✅ Validation 수행
        model.eval()
        running_loss, total_correct, total_samples = 0, 0, 0

        with torch.no_grad():
            for img, label in val_loader:
                img, label = img.to(device), label.to(device).float()
                pred = model(img)
                loss = criterion(pred, label.view(-1, 1))
                running_loss += loss.item()
                predicted = (torch.sigmoid(pred) > 0.5).float()
                total_correct += (predicted == label.view(-1, 1)).sum().item()
                total_samples += label.size(0)

        val_loss = running_loss / len(val_loader)
        val_accuracy = total_correct / total_samples

        model.train()

        # ✅ 학습 과정 출력
        print(f"Epoch [{curr_epoch + 1}/{epochs}] | "
              f"Train Loss: {train_loss:.4f} | Train Accuracy: {train_accuracy:.4f} | "
              f"Val Loss: {val_loss:.4f} | Val Accuracy: {val_accuracy:.4f}")

        train_loss_list.append(train_loss)
        valid_loss_list.append(val_loss)
        train_accuracy_list.append(train_accuracy)
        valid_accuracy_list.append(val_accuracy)

        # ✅ Best Model 저장
        if val_loss < best_loss:
            best_loss = val_loss
            torch.save(model.state_dict(), os.path.join(weights_dir, model_weights))

    # ✅ 학습 결과 그래프 저장
    plt.figure(figsize=(12, 5))
    plt.plot(range(1, epochs + 1), train_loss_list, label="Train Loss", marker="o", linestyle="-")
    plt.plot(range(1, epochs + 1), valid_loss_list, label="Validation Loss", marker="s", linestyle="--")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Train & Validation Loss - {'Augmentation' if augment else 'No Augmentation'}")
    plt.legend()
    plt.savefig(os.path.join(results_dir, f"train_validation_loss_{'augmentation' if augment else 'no_augmentation'}.png"))
    plt.close()

    plt.figure(figsize=(12, 5))
    plt.plot(range(1, epochs + 1), train_accuracy_list, label="Train Accuracy", marker="o", linestyle="-")
    plt.plot(range(1, epochs + 1), valid_accuracy_list, label="Validation Accuracy", marker="s", linestyle="--")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title(f"Train & Validation Accuracy - {'Augmentation' if augment else 'No Augmentation'}")
    plt.legend()
    plt.savefig(os.path.join(results_dir, f"train_validation_accuracy_{'augmentation' if augment else 'no_augmentation'}.png"))
    plt.close()

if __name__ == "__main__":
    main()
