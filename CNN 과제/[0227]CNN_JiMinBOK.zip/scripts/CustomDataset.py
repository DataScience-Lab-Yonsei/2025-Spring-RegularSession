import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

"""
metaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):
    def __init__(self, data_dir: str, df: pd.DataFrame, augment=False):
        self.data_dir = data_dir  # 이미지가 저장된 기본 경로
        self.df = df.reset_index(drop=True)  # 인덱스 리셋
        self.augment = augment  # 데이터 증강 여부

        # 데이터 증강 (train 데이터에만 적용)
        if self.augment:
            self.transform = transforms.Compose([
                #### TO DO ####
                
                # torchvision.transforms를 이용해 다양한 data augmentation 함수들을 사용해주세요

                transforms.RandomHorizontalFlip(p=0.5),  # 50% 확률로 좌우 반전
                transforms.RandomRotation(degrees=15),  # 랜덤 회전 (15도 이내)
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),  # 밝기/대비 등 조정
                transforms.RandomResizedCrop(size=(224, 224), scale=(0.8, 1.0)),  # 랜덤 크롭 후 리사이즈
    
                ###############
                transforms.ToTensor()
            ])
        else:
            self.transform = transforms.ToTensor()  # 정규화 없이 ToTensor()만 적용
            #self.transform = transforms.Compose([transforms.ToTensor()])



    def __len__(self) -> int:
        # self.df에 포함된 전체 데이터포인트의 수를 반환하도록 해주세요
        return len(self.df)  # 데이터프레임의 전체 행 수 반환

        
    def __getitem__(self, idx:int):
        # self.df의 각 행에서 받은 image_id, class_label, class_id을 이용해 이미지 데이터와 레이블을 반환해주세요

        # Extract image ID and class label from metadata
        filename = self.df.iloc[idx]["image_id"]  # Image filename (without extension)
        label_name = self.df.iloc[idx]["class_label"]  # 'NORMAL' or 'PNEUMONIA'

        # Determine correct directory based on label
        subfolder = "NORMAL" if label_name == "NORMAL" else "PNEUMONIA"

        # Construct full image path (default to .jpeg)
        img_path = os.path.join(self.data_dir, subfolder, filename + ".jpeg")

        # If file does not exist, check other possible extensions
        if not os.path.exists(img_path):
            for ext in [".jpg", ".png"]:
                if os.path.exists(img_path.replace(".jpeg", ext)):
                    img_path = img_path.replace(".jpeg", ext)
                    break

        # Final check: if file still doesn't exist, print warning and skip
        if not os.path.exists(img_path):
            print(f"⚠️ Warning: File {img_path} is missing! Skipping.")
            return None

        #img_name = os.path.join(self.data_dir, self.df.iloc[idx, 0])

        # Load image
        image = Image.open(img_path).convert("RGB")  # Convert to RGB
        label = int(self.df.iloc[idx]["class_id"])  # Convert label to integer (0 or 1)
    
        # Apply transformations
        if self.transform:
            image = self.transform(image)
    
        # Convert label to tensor
        label = torch.tensor(label, dtype=torch.long)  # Use long for classification

        return image, label

