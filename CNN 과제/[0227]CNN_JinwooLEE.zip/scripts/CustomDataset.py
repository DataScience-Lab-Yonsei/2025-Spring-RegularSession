import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

"""
metaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):
    def __init__(self, data_dir: str, df: pd.DataFrame, augment=False):
        self.data_dir = data_dir  # 이미지가 저장된 기본 경로
        self.df = df.reset_index(drop=True)  # 인덱스 리셋
        self.augment = augment  # 데이터 증강 여부

        # 데이터 증강 (train 데이터에만 적용)
        if self.augment:
            self.transform = transforms.Compose([
                transforms.RandomHorizontalFlip(p=0.5), 
                transforms.RandomRotation(degrees=15), 
                transforms.RandomResizedCrop(224, scale=(0.8, 1.0)), 
                transforms.ColorJitter(brightness=0.2, contrast=0.2),  
                transforms.GaussianBlur(kernel_size=3),
                transforms.RandomAffine(degrees=10, translate=(0.05, 0.05), scale=(0.9, 1.1)),
                transforms.ToTensor(), 
                transforms.RandomErasing(p=0.2, scale=(0.02, 0.1))
            ])
        else:
            self.transform = transforms.ToTensor()  # 정규화 없이 ToTensor()만 적용

    def __len__(self) -> int:
        # self.df에 포함된 전체 데이터포인트의 수를 반환하도록 해주세요
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        image_path = os.path.join(self.data_dir, row["class_label"], row["image_id"] + ".jpeg")
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"[에러] 이미지 파일이 존재하지 않습니다: {image_path}")

        image = Image.open(image_path).convert("RGB")

        label = torch.tensor(row["class_id"], dtype=torch.float32).view(-1, 1)

        # 변환 적용 (필수: ToTensor() 포함)
        image = self.transform(image)

        return image, label
