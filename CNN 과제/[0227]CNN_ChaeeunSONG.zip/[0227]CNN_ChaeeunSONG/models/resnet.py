import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        #### TO DO ####
        super(ResBottleNeck, self).__init__()
        self.expansion = 4
        
        # 1x1 conv layer
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        
        # 3x3 conv layer
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        # 1x1 conv layer
        self.conv3 = nn.Conv2d(out_channels, out_channels * self.expansion, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels * self.expansion)
        
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels * self.expansion:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels * self.expansion)
            )
        self.relu = nn.ReLU(inplace=True)
        
       
                
    def forward(self, x):
        #### TO DO ####
        identity = x
        
        out = F.relu(self.bn1(self.conv1(x)))
        
        # print(f"After conv1: {out.shape}")
        
        out = F.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        
        out += self.shortcut(identity)      
        
        ###############
        return self.relu(out)
    

class ResNet50(nn.Module):
    def __init__(self, in_channels=3, num_classes=2):
        #### TO DO ####
        super(ResNet50, self).__init__()
        self.in_channels = 64
        
        # Initial conv layer
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        
        # ResNet layers
        self.layer1 = self._make_layer(64, 3, stride = 1)  # No stride=2 here
        self.layer2 = self._make_layer(128, 4, stride=2)  # First block has stride=2
        self.layer3 = self._make_layer(256, 6, stride=2)  # First block has stride=2
        self.layer4 = self._make_layer(512, 3, stride=2)  # First block has stride=2
        
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(2048, 1)

    def _make_layer(self, out_channels, blocks, stride):
        layers = []
        layers.append(ResBottleNeck(self.in_channels, out_channels, stride))
        self.in_channels = out_channels * 4
        for _ in range(1, blocks):
            layers.append(ResBottleNeck(self.in_channels, out_channels))
        #return nn.Sequential(*layers)
        
        return nn.Sequential(*layers)


    def forward(self,x):
        #### TO DO ####
        x = self.conv1(x)
        #x = self.bn1(x)
        #x = self.relu(x)
        x = self.maxpool(x)
        
        # ResNet layers
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        # Final layers
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        
        return x

        
        ###############
       
