import os
import sys
import yaml
import argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, accuracy_score
from torch.utils.data import DataLoader

# 프로젝트 경로 설정
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(ROOT_DIR, "models"))

from CustomDataset import CustomImageDataset
from resnet import ResNet50

# 디렉토리 및 설정 파일 경로
data_dir = os.path.join(ROOT_DIR, "data")
weights_dir = os.path.join(ROOT_DIR, "weights")
results_dir = os.path.join(ROOT_DIR, "results")
config_path = os.path.join(ROOT_DIR, "configs", "config.yaml")
metadata_path = os.path.join(ROOT_DIR, "data", "metadata.csv")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
num_workers = min(4, os.cpu_count() // 2)

def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate trained ResNet50 on test dataset")
    parser.add_argument("--augment", action="store_true", help="Evaluate model trained with augmentation")
    return parser.parse_args()

def main():
    args = parse_args()
    augment = args.augment

    os.makedirs(results_dir, exist_ok=True)

    # 하이퍼파라미터 설정 로드
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if augment:
        batch_size = config["augmentation"]["hyperparameters"]["batch_size"]
        model_weights = "best_model_augmentation.pth"
    else:
        batch_size = config["no_augmentation"]["hyperparameters"]["batch_size"]
        model_weights = "best_model_no_augmentation.pth"

    # Metadata.csv 로드 및 데이터 분할
    meta_data = pd.read_csv(metadata_path)
    _, val_test = train_test_split(meta_data, train_size=0.6, random_state=2025, stratify=meta_data["class_id"])
    _, test = train_test_split(val_test, train_size=0.5, random_state=2025, stratify=val_test["class_id"])

    # CustomDataset 클래스 사용하여 데이터셋 생성
    test_dataset = CustomImageDataset(data_dir=data_dir, df=test, augment=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    # 모델 불러오기
    model = ResNet50(num_classes=2)
    model.load_state_dict(torch.load(os.path.join(weights_dir, model_weights)))
    model.to(device)
    model.eval()

    all_labels = []
    all_predictions = []

    # 모델 평가
    with torch.no_grad():
        for img, label in test_loader:
            img, label = img.to(device), label.to(device)
            pred = model(img)

            predicted = torch.argmax(pred, dim=1)
            all_labels.extend(label.cpu().numpy().tolist())
            all_predictions.extend(predicted.cpu().numpy().tolist())

    # Accuracy 계산 및 Confusion Matrix 출력
    accuracy = accuracy_score(all_labels, all_predictions)
    cm = confusion_matrix(all_labels, all_predictions)

    print(f"Test Accuracy: {accuracy * 100:.2f}%")

    # Confusion Matrix 시각화 및 저장
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(f"Confusion Matrix & Accuracy: {accuracy * 100:.2f}% - {'Augmentation' if augment else 'No Augmentation'}")
    
    if augment:
        plt.savefig(os.path.join(results_dir, "test_accuracy_augmentation.png"))
    else:
        plt.savefig(os.path.join(results_dir, "test_accuracy_no_augmentation.png"))
    
    plt.show()

if __name__ == "__main__":
    main()