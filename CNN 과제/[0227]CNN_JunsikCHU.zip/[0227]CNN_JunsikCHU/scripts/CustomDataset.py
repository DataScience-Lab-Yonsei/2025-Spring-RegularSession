import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

class CustomImageDataset(Dataset):
    def __init__(self, data_dir: str, df: pd.DataFrame, augment=False):
        self.data_dir = data_dir  # 이미지가 저장된 기본 경로
        self.df = df.reset_index(drop=True)  # 데이터프레임 인덱스 리셋
        self.augment = augment  # 데이터 증강 여부

        # ✅ **1. 데이터 증강(Augmentation) 적용 (train 데이터에만)**
        if self.augment:
            self.transform = transforms.Compose([
                transforms.RandomResizedCrop(size=224, scale=(0.8, 1.0)),  # 랜덤 크롭 후 224x224로 리사이징
                transforms.RandomHorizontalFlip(p=0.5),  # 50% 확률로 좌우 반전
                transforms.RandomRotation(degrees=10),  # 랜덤 회전 (-10도 ~ +10도)
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),  # 색상 변화
                transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),  # 이미지 이동 변환
                transforms.ToTensor(),  # PyTorch Tensor 변환
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 정규화
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((224, 224)),  # 고정 크기로 변환
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int):
        # ✅ **2. 이미지 로드**
        row = self.df.iloc[idx]
        
        # 📌 `class_label`을 사용하여 폴더 선택
        image_path = os.path.join(self.data_dir, row["class_label"], row["image_id"] + ".jpeg")
        
        # ✅ **3. 파일 존재 여부 확인**
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"🚨 이미지 파일이 존재하지 않습니다: {image_path}")

        # ✅ **4. 이미지 변환 적용**
        image = Image.open(image_path).convert("RGB")
        image = self.transform(image)

        # ✅ **5. 라벨 변환 (NORMAL=0, PNEUMONIA=1)**
        label = 1 if row["class_label"] == "PNEUMONIA" else 0
        label = torch.tensor(label, dtype=torch.float32)  # BCEWithLogitsLoss 사용을 위해 float으로 변환

        return image, label
